import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

interface UserDetails {
  aboutMyFamily: string;
  fatherName: string;
  fatherOccupation: string;
  motherName: string;
  motherOccupation: string;
  familyStatus: string;
  sisters: string;
  sistersMarried: string;
  brothers: string;
  brothersMarried: string;
  propertyDetails: string;
}

interface UserDetailsState {
  details: UserDetails | null;
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}

const initialState: UserDetailsState = {
  details: null,
  status: 'idle',
  error: null,
};

export const fetchUserDetails = createAsyncThunk(
  'userDetails/fetchUserDetails',
  async ({ profile_id, page_id }: { profile_id: string; page_id: string }) => {
    try {
      const response = await axios.post('http://103.214.132.20:8000/auth/Get_save_details/', {
        profile_id,
        page_id,
      });
      console.log('API response:', response.data);
      return response.data.data; // Assuming response.data.data contains user details
    } catch (error) {
      console.error('API error:', error);
      throw Error('Failed to fetch user details');
    }
  }
);

const userDetailsSlice = createSlice({
  name: 'userDetails',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserDetails.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchUserDetails.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.details = action.payload;
      })
      .addCase(fetchUserDetails.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || 'Failed to fetch user details';
      });
  },
});

export default userDetailsSlice.reducer;
