// src/config.js
const config = {
    apiUrl: 'http://103.214.132.20:8000',
  };
  
  export default config;
  