import VysyaBazaarImg from "../../assets/images/VysyaBazaar.png";
export const VysyaBazaar = () => {
  return (
    <div>
      <div className="container mx-auto my-20">
        <div>
          <img src={VysyaBazaarImg} alt="Vysysa Bazaar" className="w-full" />
        </div>
      </div>
    </div>
  );
};
