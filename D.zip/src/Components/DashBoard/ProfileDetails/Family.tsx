// import React, { useEffect } from 'react';
// import { MdModeEdit } from "react-icons/md";
// import { useDispatch, useSelector } from 'react-redux';
// import { RootState } from "../../../Redux/Store/store";
// import { fetchUserDetails } from "../../../Redux/Slice/userDetailSlice";

// export const Family = () => {
//   const dispatch = useDispatch();

//   const profile_id = 'VY240050';
//   const page_id ='3'; // Replace with your actual page_id logic

//   useEffect(() => {
//     if (profile_id) {
//       console.log('Dispatching fetchUserDetails with:', { profile_id, page_id });
//       dispatch(fetchUserDetails({ profile_id, page_id }));
//     }
//   }, [dispatch, profile_id, page_id]);

//   const userDetails = useSelector((state: RootState) => state.userDetails.details);
//   const loading = useSelector((state: RootState) => state.userDetails.status === 'loading');
//   const error = useSelector((state: RootState) => state.userDetails.error);

//   console.log('Component userDetails:', userDetails);
//   console.log('Component loading:', loading);
//   console.log('Component error:', error);

//   if (loading) return <div>Loading...</div>;
//   if (error) return <div>Error: {error}</div>;

//   return (
//     <div>
//       <h2 className="flex items-center text-[30px] text-vysyamalaBlack font-bold mb-5">Family Details
//         <MdModeEdit className="text-2xl text-main ml-2 cursor-pointer" />
//       </h2>
//       <div>
//         <div className="grid grid-rows-1 grid-cols-2">
//           <div>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">About My Family :
//               <span className="font-normal"> {userDetails?.about_family || '-'}</span></h5>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Father Name :
//               <span className="font-normal"> {userDetails?.father_name || 'K. Karthikeyan (Late)'}</span></h5>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Father Occupation :
//               <span className="font-normal"> {userDetails?.father_occupation || '-'}</span></h5>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Mother Name :
//               <span className="font-normal"> {userDetails?.mother_name || 'K. Sujatha (Late)'}</span></h5>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Mother Occupation :
//               <span className="font-normal"> {userDetails?. mother_occupation|| 'Pollachi'}</span></h5>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Family Status :
//               <span className="font-normal"> {userDetails?.family_Status || 'Upper Middle Class'}</span></h5>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Sisters :
//               <span className="font-normal"> {userDetails?. no_of_sister || 'No'}</span></h5>
//           </div>
//           <div>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Sisters Married :
//               <span className="font-normal"> {userDetails?. no_of_sis_married || 'No'}</span></h5>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Brothers :
//               <span className="font-normal"> {userDetails?. no_of_brother || 'No'}</span></h5>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Brothers Married :
//               <span className="font-normal"> {userDetails?.  no_of_bro_married || 'No'}</span></h5>
//             <h5 className="text-[20px] text-ash font-semibold mb-2">Property Details :
//               <span className="font-normal"> {userDetails?.  property_details || '-'}</span></h5>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

import React, { useEffect } from 'react';
import { MdModeEdit } from "react-icons/md";
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from "../../../Redux/Store/store";
import { fetchUserDetails } from "../../../Redux/Slice/userDetailSlice";

export const Family = () => {
  const dispatch = useDispatch();

  const profile_id = 'VY240050';
  const page_id = '3'; // Replace with your actual page_id logic

  useEffect(() => {
    if (profile_id) {
      console.log('Dispatching fetchUserDetails with:', { profile_id, page_id });
      dispatch(fetchUserDetails({ profile_id, page_id }));
    }
  }, [dispatch, profile_id, page_id]);

  const userDetails = useSelector((state: RootState) => state.userDetails.details);
  const loading = useSelector((state: RootState) => state.userDetails.status === 'loading');
  const error = useSelector((state: RootState) => state.userDetails.error);

  console.log('userDetails:', userDetails);
  console.log('Component loading:', loading);
  console.log('Component error:', error);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h2 className="flex items-center text-[30px] text-vysyamalaBlack font-bold mb-5">Family Details
        <MdModeEdit className="text-2xl text-main ml-2 cursor-pointer" />
      </h2>
      <div>
        <div className="grid grid-rows-1 grid-cols-2">
          <div>
            <h5 className="text-[20px] text-ash font-semibold mb-2">About My Family :
              <span className="font-normal"> {userDetails?.about_family || '-'}</span></h5>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Father Name :
              <span className="font-normal"> {userDetails?.father_name || '-'}</span></h5>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Father Occupation :
              <span className="font-normal"> {userDetails?.father_occupation || '-'}</span></h5>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Mother Name :
              <span className="font-normal"> {userDetails?.mother_name || '-'}</span></h5>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Mother Occupation :
              <span className="font-normal"> {userDetails?.mother_occupation || '-'}</span></h5>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Family Status :
              <span className="font-normal"> {userDetails?.family_status || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">Family Value :
              <span className="font-normal"> {userDetails?.family_value || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">Family Type :
              <span className="font-normal"> {userDetails?.family_type || '-'}</span></h5>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Sisters :
              <span className="font-normal"> {userDetails?.no_of_sister || '-'}</span></h5>
         <h5 className="text-[20px] text-ash font-semibold mb-2">Hobbies :
              <span className="font-normal"> {userDetails?.hobbies || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">About YourSelf :
              <span className="font-normal"> {userDetails?.about_self || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">Blood Group :
              <span className="font-normal"> {userDetails?.blood_group || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">Physically Challenged:
              <span className="font-normal"> {userDetails?.Pysically_changed || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">Sisters :
              <span className="font-normal"> {userDetails?.no_of_sister || '-'}</span></h5>
         
          </div>
          <div>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Sisters Married :
              <span className="font-normal"> {userDetails?.no_of_sis_married || '-'}</span></h5>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Brothers :
              <span className="font-normal"> {userDetails?.no_of_brother || '-'}</span></h5>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Brothers Married :
              <span className="font-normal"> {userDetails?.no_of_bro_married || '-'}</span></h5>
            <h5 className="text-[20px] text-ash font-semibold mb-2">Property Details :
              <span className="font-normal"> {userDetails?.property_details || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">Property Worth :
              <span className="font-normal"> {userDetails?.property_worth || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">Suya Gothram :
              <span className="font-normal"> {userDetails?.suya_gothram || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">Uncle Orgin :
              <span className="font-normal"> {userDetails?.uncle_gothram || '-'}</span></h5>
              <h5 className="text-[20px] text-ash font-semibold mb-2">Ancester Orgin :
              <span className="font-normal"> {userDetails?.ancestor_origin || '-'}</span></h5>
          </div>
        </div>
      </div>
    </div>
  );
};
